SELECT matchId, DBNOs FROM player_statistic ORDER BY DBNOs DESC LIMIT 20;
