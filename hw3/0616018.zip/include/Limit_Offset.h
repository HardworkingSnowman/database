#ifndef LIMIT_OFFSET_H
#define LIMIT_OFFSET_H
#include "Table.h"
#include "Command.h"

typedef struct limoff{
  int limit, offset;
} Limoff_t;

Limoff_t *new_limoff(Table_t *table);
void handle_limoff_error(int errcode);
int handle_limoff(Command_t *cmd, int i, Limoff_t *lo);
int check_limoff_value(Limoff_t *lo, Table_t *talbe);

#endif