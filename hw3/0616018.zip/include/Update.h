#ifndef UPDATE_H
#define UPDATE_H
#include "Where.h"
#include "Table.h"
#include "Command.h"

typedef struct Update_query{
  char left[100][100], right[100][100];
  int set_num;
} Update_query_t;

Update_query_t *new_update_query();
void handle_update_set(Command_t *cmd, Update_query_t *uq, int i);
int check_update_error(Table_t *table, Update_query_t *uq, Where_arg_t *arg);
void update_table(Table_t *table, Update_query_t *uq, Where_arg_t *arg);
void handle_update_error(int errcode);

#endif