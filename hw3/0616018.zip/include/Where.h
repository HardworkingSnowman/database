#ifndef WHERE_H
#define WHERE_H
#include "Command.h"
#include "User.h"

// char white_list[4][20]={"id", "name", "email", "age"};
// char operators[6][5]={"=", "!=", ">", "<", ">=", "<="};
// char logics[2][10]={"or", "and"};

typedef struct Where_arg{
  char op[100][100], logic[100][100];
  int where_num, is_there_where;
  char left[100][100], right[100][100];
} Where_arg_t;
Where_arg_t *new_where_arg();
int check_whether_num(char *s);
int check_column_name(char *s);
void handle_where_arg(char *cmd, Where_arg_t *arg);
int handle_where_whole(Command_t *cmd, Where_arg_t *arg, int i);
void handle_where_error(int errcode);
int meet_where_condition(User_t *user, Where_arg_t *arg);
int check_where_error(Where_arg_t *arg);
int int_operator(int left, char *op, int right);
int str_operator(char *left, char *op, char *right);

#endif