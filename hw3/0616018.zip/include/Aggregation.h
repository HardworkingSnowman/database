#ifndef AGGREGATION_H
#define AGGREGATION_H
#include "Command.h"
#include "Table.h"
#include "Where.h"

// char aggre_func[3][20]={"avg", "count", "sum"};
typedef struct Aggre_log{
  int col_type[20], aggre_type[20], left_quot[20], right_quot[20], total;
}Aggre_log_t;

Aggre_log_t *new_aggre_log();
int check_if_aggre(Command_t *cmd);
int check_aggre_func(Command_t *cmd, Aggre_log_t *al);
void print_aggre(Table_t *table, Command_t *cmd, Where_arg_t *arg, Aggre_log_t *al);
void handle_aggre_error(int errcode);

#endif