#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Table.h"
#include "Command.h"
#include "Limit_Offset.h"
#include "Where.h"

//初始化 limoff_t
Limoff_t *new_limoff(Table_t *table){
  Limoff_t *lo = (Limoff_t*)malloc(sizeof(Limoff_t));
  memset((void*)lo, 0, sizeof(Limoff_t));
  lo->limit=table->len;
  lo->offset=0;
  return lo;
}

int handle_limoff(Command_t *cmd, int i, Limoff_t *lo){
  if(i+1>=cmd->args_len){
    handle_limoff_error(1);
    return 0;
  }
  else if(check_whether_num(cmd->args[i+1]) && !strncmp(cmd->args[i], "offset", 10000)){
    lo->offset=atoi(cmd->args[i+1]);
    return 1;
  }
  else if(check_whether_num(cmd->args[i+1]) && !strncmp(cmd->args[i], "limit", 10000)){
    lo->limit=atoi(cmd->args[i+1]);
    return 1;
  }
  else if(!strncmp(cmd->args[i], "offset", 10000) || !strncmp(cmd->args[i], "limit", 10000)){
    handle_limoff_error(0);
    return 0;
  }
  return 1;
}

int check_limoff_value(Limoff_t *lo, Table_t *table){
  if(lo->offset < 0 || lo->limit <0){
    handle_limoff_error(0);
    return 0;
  }
  else if(lo->offset + lo->limit > table->len)lo->limit = table->len - lo->offset;
  return 1;
}

void handle_limoff_error(int errcode){
  switch(errcode){
    case 0:{
      printf("invalid arg for offset or limit\n");
      break;
    }
    case 1:{
      printf("No arg for the option\n");
      break;
    }
  }
}