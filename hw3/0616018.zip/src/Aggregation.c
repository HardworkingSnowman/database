#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Command.h"
#include "Table.h"
#include "Aggregation.h"
#include "Where.h"
#include "User.h"

// 初始化 Aggre_log_t
Aggre_log_t *new_aggre_log(){
  Aggre_log_t *al = (Aggre_log_t*)malloc(sizeof(Aggre_log_t));
  memset((void*)al, 0, sizeof(Aggre_log_t));
  for(int i=0; i<20; i++){
    al->aggre_type[i]=-1;
    al->col_type[i]=-1;
    al->left_quot[i]=0;
    al->right_quot[i]=0;
  }
  al->total=0;
  return al;
}
// 如果 select 的東西不在 column name 中，就先判斷為是 aggregation function 並回傳 1
int check_if_aggre(Command_t *cmd){
  char white_list[4][20]={"id", "name", "email", "age"};
  int check=0;
  for(int i=0; i<4; i++){
    if(!strncmp(cmd->args[1], white_list[i], strlen(white_list[i])))check=1;
    else if(cmd->args[1][0]=='*')check=1;
  }
  if(check)return 0;
  else return 1;
}
// 確認有沒有任何錯誤在 check_aggre_function 中，正常就回傳 1
int check_aggre_func(Command_t *cmd, Aggre_log_t *al){
  char aggre_func[3][20]={"avg", "count", "sum"};
  char white_list[5][20]={"id", "name", "email", "age", "*"};
  for(int j=1; j<cmd->args_len; j++){
    if(!strncmp(cmd->args[j], "from", 10))break;
    al->total++;
    // 先看左括弧跟右括弧存在
    for(int i=0; i<strlen(cmd->args[j]); i++){
      if(cmd->args[j][i]=='(')al->left_quot[j-1]=i;
      else if(cmd->args[j][i]==')')al->right_quot[j-1]=i;
    }
    if(!al->left_quot[j-1] || !al->right_quot[j-1]){
      handle_aggre_error(1);
      return 0;
    }
    // 確認 aggregation function 存在
    for(int i=0; i<3; i++){
      if(!strncmp(cmd->args[j], aggre_func[i], strlen(aggre_func[i])))al->aggre_type[j-1]=i;
    }
    if(al->aggre_type[j-1]==-1){
      handle_aggre_error(0);
      return 0;
    }
    // 確認括弧中的 column name 存在
    char *col_name = (char*)malloc(sizeof(char)*20);
    for(int i=al->left_quot[j-1]+1; i<al->right_quot[j-1]; i++){
      col_name[i - (al->left_quot[j-1]+1)] = cmd->args[j][i];
    }
    for(int i=0; i<5; i++){
      if(!strncmp(col_name, white_list[i], 10))al->col_type[j-1]=i;
    }
    if(al->col_type[j-1]==-1){
      handle_aggre_error(3);
      return 0;
    }
    // 確認 aggregation 裡面的 datatype 是否相合，ex. name 和 email 不能用 sum, avg
    if((!strncmp(white_list[al->col_type[j-1]], "name", 10) || !strncmp(white_list[al->col_type[j-1]], "email", 10)) && (!strncmp(aggre_func[al->aggre_type[j-1]], "sum", 10) || !strncmp(aggre_func[al->aggre_type[j-1]], "avg", 10))){
      handle_aggre_error(2);
      return 0;
    }
  }
  return 1;
}
// print 出 aggregation function 的結果
void print_aggre(Table_t *table, Command_t *cmd, Where_arg_t *arg, Aggre_log_t *al){
  for(int j=0; j<al->total; j++){
    int res=0, cnt=0;
    for(int i=0; i<table->len; i++){
      User_t *user=get_User(table, i);
      if(user!=NULL){
        if(meet_where_condition(user, arg)){
          if(al->col_type[j]==0)res += user->id;
          else res += user->age;
          cnt++;
        }
      }
    }
    if(!j)printf("(");
    else printf(", ");
    if(al->aggre_type[j]==0){
      printf("%.3lf", (double)res/(double)cnt);
    }
    else if(al->aggre_type[j]==1)printf("%d", cnt);
    else printf("%d", res);
  }
  printf(")\n");
}
// 錯誤處理
void handle_aggre_error(int errcode){
  switch(errcode){
    case 0:{
      printf("undefined aggregation function\n");
      break;
    }
    case 1:{
      printf("wrong format for aggregation function\n");
      break;
    }
    case 2:{
      printf("wrong datatype for the aggregation function\n");
      break;
    }
    case 3:{
      printf("undefined column in aggregation function\n");
      break;
    }
  }
}