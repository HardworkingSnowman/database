#include "Command.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Where.h"
#include "User.h"


// 確認是否為數字字串
int check_whether_num(char *s){
    for(int j=0; j<strlen(s); j++){
        if((j==0 && s[j]=='-') || s[j]=='.')continue;
        else if(s[j]-'0'<0 || s[j]-'0'>9)return 0;
    }
    return 1;
}
// 確認欄位無誤
int check_column_name(char *s){
    char white_list[4][20]={"id", "name", "email", "age"};
    for(int i=0; i<4; i++){
        if(!strncmp(s, white_list[i], 10))return i;
    }
    return -1;
}
// 確認比較的字串，以及 op 是否為 =, !=，1 為 true，0 為 false，-1 為 error
int str_operator(char *left, char *op, char *right){
    char operators[6][5]={"=", "!=", ">", "<", ">=", "<="};
    if(!strncmp(op, operators[0], 10)){
        if(!strncmp(left, right, 1000))return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[1], 10)){
        if(strncmp(left, right, 1000))return 1;
        else return 0;
    }
    else return 0;
}
// 確認比較的整數，以及 op 是否為 =, !=, >, <, >=, <=，1 為 true，0 為 false，-1 為 error
int int_operator(int left, char *op, int right){
    char operators[6][5]={"=", "!=", ">", "<", ">=", "<="};
    if(!strncmp(op, operators[0], 10)){
        if(left == right)return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[1], 10)){
        if(left != right)return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[2], 10)){
        if(left > right)return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[3], 10)){
        if(left < right)return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[4], 10)){
        if(left >= right)return 1;
        else return 0;
    }
    else if(!strncmp(op, operators[5], 10)){
        if(left <= right)return 1;
        else return 0;
    }
    else return 0;
}

// 確認是否符合條件，再決定要不要 printf，
int meet_where_condition(User_t *user, Where_arg_t *arg){
    char white_list[4][20]={"id", "name", "email", "age"};
    // 先確認每個敘述是 true 還是 false
    int check[arg->where_num];
    for(int i=0; i<arg->where_num; i++){
        check[i]=0;
        if(!strncmp(arg->left[i], white_list[0], 10) || !strncmp(arg->left[i], white_list[3], 10)){
            if(!strncmp(arg->left[i], white_list[0], 10))check[i] = int_operator(user->id, arg->op[i], atoi(arg->right[i]));
            else check[i] = int_operator(user->age, arg->op[i], atoi(arg->right[i]));
        }
        else if(!strncmp(arg->left[i], white_list[1], 10))check[i] = str_operator(user->name, arg->op[i], arg->right[i]);
        else if(!strncmp(arg->left[i], white_list[2], 10))check[i] = str_operator(user->email, arg->op[i], arg->right[i]);
    }
    // 再來確認是 or 還是 and
    int last;
    if(!arg->where_num)last=1;
    else last=check[0];
    for(int i=0; i<arg->where_num-1; i++){
        if(!strncmp(arg->logic[i], "and", 10))last = (last & check[i+1]);
        else last = (last | check[i+1]);
    }
    return last;
}
// 檢查 where 是否有誤
int check_where_error(Where_arg_t *arg){
    char logics[2][10]={"or", "and"};
    char operators[6][5]={"=", "!=", ">", "<", ">=", "<="};
    char white_list[4][20]={"id", "name", "email", "age"};
    // 確認 left 都是 id, name, email, age 其中一個
    for(int i=0; i<arg->where_num; i++){
        int check=0;
        for(int j=0; j<4; j++){
            if(!strncmp(arg->left[i], white_list[j], 10)){
                check=1;
                break;
            }
        }
        if(!check){
            handle_where_error(1);
            return 0;
        }
    }
    // 確認 op 在 id 或 age 時是 =, !=, >, <, >=, <=; 在 name, email 時是 =, !=
    for(int i=0; i<arg->where_num; i++){
        if(!strncmp(arg->left[i], white_list[0], 10) || !strncmp(arg->left[i], white_list[3], 10)){
            int check=0;
            for(int j=0; j<6; j++){
                if(strncmp(arg->left[i], operators[j], 10)){
                    check=1;
                    break;
                }
            }
            if(!check){
                handle_where_error(3);
                return 0;
            }
        }
        else{
            int check=0;
            for(int j=0; j<2; j++){
                if(strncmp(arg->left[i], operators[j], 10)){
                    check=1;
                    break;
                }
            }
            if(!check){
                handle_where_error(3);
                return 0;
            }
        }
    }
    // 確認 right 在 id, age 時是不是數字
    for(int i=0; i<arg->where_num; i++){
        char white_list[4][20]={"id", "name", "email", "age"};
        if(!strncmp(arg->left[i], white_list[0], 10) || !strncmp(arg->left[i], white_list[3], 10)){
            if(!check_whether_num(arg->right[i])){
                handle_where_error(2);
                return 0;
            }
        }
    }
    // 確認 logic 是否為 or, and
    for(int i=0; i<arg->where_num-1; i++){
        int check=0;
        for(int j=0; j<2; j++){
            if(!strncmp(arg->logic[i], logics[j], 10)){
                check=1;
                break;
            }    
        }
        if(!check){
            handle_where_error(0);
            return 0;
        }
    }
    return 1;
}

// 跑過每個 numeric operators
void handle_where_arg(char *cmd, Where_arg_t *arg){
    for(int j=1; j<strlen(cmd)-1; j++){
        if(cmd[j]=='!' && cmd[j+1]=='=')strcpy(arg->op[arg->where_num], "!=");
        else if(cmd[j]=='=')strcpy(arg->op[arg->where_num], "=");
        else if(cmd[j]=='>' && cmd[j+1]=='=')strcpy(arg->op[arg->where_num], ">=");
        else if(cmd[j]=='>')strcpy(arg->op[arg->where_num], ">");
        else if(cmd[j]=='<' && cmd[j+1]=='=')strcpy(arg->op[arg->where_num], "<=");
        else if(cmd[j]=='<')strcpy(arg->op[arg->where_num], "<");
        else strcpy(arg->op[arg->where_num], "wrong");

        for(int k=0; k<j; k++)arg->left[arg->where_num][k]=cmd[k];
        if(!strncmp(arg->op[arg->where_num], "=", 10) || !strncmp(arg->op[arg->where_num], ">", 10) || !strncmp(arg->op[arg->where_num], "<", 10)){
            for(int k=j+1; k<strlen(cmd); k++)arg->right[arg->where_num][k-(j+1)]=cmd[k];
            break;
        }
        else if(!strncmp(arg->op[arg->where_num], "!=", 10) || !strncmp(arg->op[arg->where_num], ">=", 10) || !strncmp(arg->op[arg->where_num], "<=", 10)){
            for(int k=j+2; k<strlen(cmd); k++)arg->right[arg->where_num][k-(j+2)]=cmd[k];
            break;
        }
    }
}
// 跑過每個 logic operators，並且呼叫 handle_where_arg，把每個參數存在 left op right logic 中，最後回傳有沒有 error
int handle_where_whole(Command_t *cmd, Where_arg_t *arg, int i){
    int logic_index=i+1;
    arg->is_there_where=1;
    while(logic_index < cmd->args_len){
        // 看是 1.a = b  2.a=b  3.a= b  4.a =b
        // 2
        if(logic_index+1 == cmd->args_len || !strncmp(cmd->args[logic_index+1], "or", 20) || !strncmp(cmd->args[logic_index+1], "and", 20)){
            if(logic_index+1<cmd->args_len)strcpy(arg->logic[arg->where_num], cmd->args[logic_index+1]);
            handle_where_arg(cmd->args[logic_index], arg);
            logic_index+=2;
        }
        // 3, 4
        else if(logic_index+2 == cmd->args_len || !strncmp(cmd->args[logic_index+2], "or", 20) || !strncmp(cmd->args[logic_index+2], "and", 20)){
            if(logic_index+2<cmd->args_len)strcpy(arg->logic[arg->where_num], cmd->args[logic_index+2]);
            // 4
            char tmp, tmp2;
            tmp = cmd->args[logic_index+1][0];
            if(tmp == '!' || tmp == '>' || tmp == '<' || tmp == '='){
                tmp2 = cmd->args[logic_index+1][1];
                strcpy(arg->left[arg->where_num], cmd->args[logic_index]);
                if(tmp2 == '>' || tmp2 == '<' || tmp2 == '='){
                    arg->op[arg->where_num][0]=tmp;
                    arg->op[arg->where_num][1]=tmp2;
                    for(int i=2; i<strlen(cmd->args[logic_index+1]); i++)arg->right[arg->where_num][i-2] = cmd->args[logic_index+1][i];
                }
                else{
                    arg->op[arg->where_num][0]=tmp;
                    for(int i=1; i<strlen(cmd->args[logic_index+1]); i++)arg->right[arg->where_num][i-1] = cmd->args[logic_index+1][i];
                }
            }
            // 3
            tmp = cmd->args[logic_index][strlen(cmd->args[logic_index])-1];
            if(tmp == '=' || tmp == '>' || tmp == '<'){
                tmp2 = cmd->args[logic_index][strlen(cmd->args[logic_index]-2)];
                strcpy(arg->right[arg->where_num], cmd->args[logic_index+1]);
                if(tmp2 == '>' || tmp2 == '<' || tmp2 == '!'){
                    arg->op[arg->where_num][0]=tmp;
                    arg->op[arg->where_num][1]=tmp2;
                    for(int i=0; i<strlen(cmd->args[logic_index])-2; i++)arg->left[arg->where_num][i] = cmd->args[logic_index][i];
                }
                else{
                    arg->op[arg->where_num][0]=tmp;
                    for(int i=0; i<strlen(cmd->args[logic_index])-1; i++)arg->left[arg->where_num][i] = cmd->args[logic_index][i];
                }
            }
            logic_index+=3;
        }
        // 1
        else if(logic_index+3 == cmd->args_len || !strncmp(cmd->args[logic_index+3], "or", 20) || !strncmp(cmd->args[logic_index+3], "and", 20)){
            if(logic_index+3 < cmd->args_len)strcpy(arg->logic[arg->where_num], cmd->args[logic_index+3]);
            strcpy(arg->left[arg->where_num], cmd->args[logic_index]);
            strcpy(arg->op[arg->where_num], cmd->args[logic_index+1]);
            strcpy(arg->right[arg->where_num], cmd->args[logic_index+2]);
            logic_index+=4;
        }
        arg->where_num++;
    }
    return 1;
}
// 初始化參數
Where_arg_t *new_where_arg(){
    Where_arg_t *arg = (Where_arg_t*)malloc(sizeof(Where_arg_t));
    memset((void*)arg, 0, sizeof(Where_arg_t));
    arg->is_there_where=0;
    arg->where_num=0;
    return arg;
}
// 錯誤處理
void handle_where_error(int errcode){
  switch(errcode){
    case 0:{
      printf("wrong logical operators in where clause\n");
      break;
    }
    case 1:{
      printf("undefined column name in where clause\n");
      break;
    }
    case 2:{
      printf("column's datatype is different from value's in where clause\n");
      break;
    }
    case 3:{
      printf("undefined numeric operators in where clause\n");
      break;
    }
    default:{
      printf("something wrong in where clause\n");
      break;
    }
  }
}