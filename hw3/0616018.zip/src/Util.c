#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include "Util.h"
#include "Command.h"
#include "Table.h"
#include "Where.h"
#include "Limit_Offset.h"
#include "Update.h"
#include "Aggregation.h"

///
/// Allocate State_t and initialize some attributes
/// Return: ptr of new State_t
///
State_t* new_State() {
    State_t *state = (State_t*)malloc(sizeof(State_t));
    state->saved_stdout = -1;
    return state;
}

///
/// Print shell prompt
///
void print_prompt(State_t *state) {
    if (state->saved_stdout == -1) {
        printf("db > ");
    }
}

///
/// Print the user in the specific format
///
void print_user(User_t *user, Command_t *cmd, Where_arg_t *arg) {
    char white_list[4][20]={"id", "name", "email", "age"};
    char order[4][20];
    int check_all_0=1;
    for(int i=0; i<cmd->args_len; i++){
        if(!strncmp("from", cmd->args[i], 10))break;
        for(int j=0; j<4; j++){
            if(!strncmp(white_list[j], cmd->args[i], strlen(white_list[j]))){
                check_all_0=0;
                for(int k=0; k<strlen(white_list[j]); k++){
                    order[i][k]=white_list[j][k];
                }
            }
        }
    }
    if(check_all_0){
        if(meet_where_condition(user, arg))printf("(%d, %s, %s, %d)\n", user->id, user->name, user->email, user->age);
    }
    else{
        int check_before=0;
        for(int i=0; i<4; i++){
            for(int j=0; j<4; j++){
                if(!strncmp(order[i], white_list[j], strlen(white_list[j])) && meet_where_condition(user, arg)){
                    if(check_before)printf(", ");
                    else printf("(");
                    if(j==0)printf("%d", user->id);
                    else if(j==1)printf("%s", user->name);
                    else if(j==2)printf("%s", user->email);
                    else if(j==3)printf("%d", user->age);
                    check_before=1;
                }
            }
        }
        if(check_before)printf(")\n");
    }
}

///
/// This function received an output argument
/// Return: category of the command
///
int parse_input(char *input, Command_t *cmd) {
    char *token;
    int idx;
    token = strtok(input, " \n");
    for (idx = 0; strlen(cmd_list[idx].name) != 0; idx++) {
        if (!strncmp(token, cmd_list[idx].name, cmd_list[idx].len)) {
            cmd->type = cmd_list[idx].type;
        }
    }
    while (token != NULL) {
        add_Arg(cmd, token);
        token = strtok(NULL, " \n");
    }
    return cmd->type;
}

///
/// Handle built-in commands
/// Return: command type
///
void handle_builtin_cmd(Table_t *table, Command_t *cmd, State_t *state) {
    if (!strncmp(cmd->args[0], ".exit", 5)) {
        archive_table(table);
        exit(0);
    } else if (!strncmp(cmd->args[0], ".output", 7)) {
        if (cmd->args_len == 2) {
            if (!strncmp(cmd->args[1], "stdout", 6)) {
                close(1);
                dup2(state->saved_stdout, 1);
                state->saved_stdout = -1;
            } else if (state->saved_stdout == -1) {
                int fd = creat(cmd->args[1], 0644);
                state->saved_stdout = dup(1);
                if (dup2(fd, 1) == -1) {
                    state->saved_stdout = -1;
                }
                __fpurge(stdout); //This is used to clear the stdout buffer
            }
        }
    } else if (!strncmp(cmd->args[0], ".load", 5)) {
        if (cmd->args_len == 2) {
            load_table(table, cmd->args[1]);
        }
    } else if (!strncmp(cmd->args[0], ".help", 5)) {
        print_help_msg();
    }
}

///
/// Handle query type commands
/// Return: command type
///
int handle_query_cmd(Table_t *table, Command_t *cmd) {
    if (!strncmp(cmd->args[0], "insert", 6)) {
        handle_insert_cmd(table, cmd);
        return INSERT_CMD;
    } 
    else if (!strncmp(cmd->args[0], "select", 6)) {
        handle_select_cmd(table, cmd);
        return SELECT_CMD;
    }
    else if(!strncmp(cmd->args[0], "update", 6)) {
        handle_update_cmd(table, cmd);
        return UPDATE_CMD;
    }
    else if(!strncmp(cmd->args[0], "delete", 6)){
        handle_delete_cmd(table, cmd);
        return DELETE_CMD;
    }
    else {
        return UNRECOG_CMD;
    }
}

///
/// The return value is the number of rows insert into table
/// If the insert operation success, then change the input arg
/// `cmd->type` to INSERT_CMD
///
int handle_insert_cmd(Table_t *table, Command_t *cmd) {
    int ret = 0;
    User_t *user = command_to_User(cmd);
    if (user) {
        ret = add_User(table, user);
        if (ret > 0) {
            cmd->type = INSERT_CMD;
        }
    }
    return ret;
}

///
/// The return value is the number of rows select from table
/// If the select operation success, then change the input arg
/// `cmd->type` to SELECT_CMD
///

int handle_select_cmd(Table_t *table, Command_t *cmd) {
    size_t idx;
    Limoff_t *lo = new_limoff(table);
    Where_arg_t *arg = new_where_arg();
    Aggre_log_t *al = new_aggre_log();
    for(int i=0; i<cmd->args_len; i++){
        if(!strncmp(cmd->args[i], "offset", 10) || !strncmp(cmd->args[i], "limit", 10)){
            if(handle_limoff(cmd, i, lo))continue;
            else return 0;
        }
        else if(!strncmp(cmd->args[i], "where", 10)){
            if( handle_where_whole(cmd, arg, i))continue;
            else return 0;
        }
    }
    if(check_if_aggre(cmd)){
        if(check_aggre_func(cmd, al)){
            print_aggre(table, cmd, arg, al);
        }
        else return 0;
    }
    else{
        if(check_limoff_value(lo, table)){
            for(idx = lo->offset; idx < lo->offset + lo->limit; idx++) {
                User_t *user=get_User(table, idx);
                if(user!=NULL)print_user(get_User(table, idx), cmd, arg);
            }
            cmd->type = SELECT_CMD;
        }
        else return 0;
    }
    return table->len;
}

///
/// If the UPDATE operation success, then change the input arg
/// `cmd->type` to UPDATE_CMD
/// return sum of updated users
///
int handle_update_cmd(Table_t *table, Command_t *cmd){
    Update_query_t *uq = new_update_query();
    Where_arg_t *arg = new_where_arg();
    for(int i=0; i<cmd->args_len; i++){
        if(!strncmp(cmd->args[i], "set", 3))handle_update_set(cmd, uq, i);
        else if(!strncmp(cmd->args[i], "where", 10))handle_where_whole(cmd, arg, i);
    }
    if(check_update_error(table, uq, arg) && check_where_error(arg)){
        cmd->type=UPDATE_CMD;
        update_table(table, uq, arg);
        return table->len;
    }
    else return 0;
    return 0;
}

///
/// If the UPDATE operation success, then change the input arg
/// `cmd->type` to DELETE_CMD
/// return sum of deleted users
///
int handle_delete_cmd(Table_t *table, Command_t *cmd){
    Where_arg_t *arg = new_where_arg();
    for(int i=0; i<cmd->args_len; i++){
        if(!strncmp(cmd->args[i], "where", 10))handle_where_whole(cmd, arg, i);
    }
    if(check_where_error(arg)){
        for(int i=0; i<table->len; i++){
            User_t *user=get_User(table, i);
            if(user != NULL){
                if(meet_where_condition(user, arg)){
                    user->deleted=1;
                }
            }
        }
    }
    return 0;
}

///
/// Show the help messages
///
void print_help_msg() {
    const char msg[] = "# Supported Commands\n"
    "\n"
    "## Built-in Commands\n"
    "\n"
    "  * .exit\n"
    "\tThis cmd archives the table, if the db file is specified, then exit.\n"
    "\n"
    "  * .output\n"
    "\tThis cmd change the output strategy, default is stdout.\n"
    "\n"
    "\tUsage:\n"
    "\t    .output (<file>|stdout)\n\n"
    "\tThe results will be redirected to <file> if specified, otherwise they will display to stdout.\n"
    "\n"
    "  * .load\n"
    "\tThis command loads records stored in <DB file>.\n"
    "\n"
    "\t*** Warning: This command will overwrite the records already stored in current table. ***\n"
    "\n"
    "\tUsage:\n"
    "\t    .load <DB file>\n\n"
    "\n"
    "  * .help\n"
    "\tThis cmd displays the help messages.\n"
    "\n"
    "## Query Commands\n"
    "\n"
    "  * insert\n"
    "\tThis cmd inserts one user record into table.\n"
    "\n"
    "\tUsage:\n"
    "\t    insert <id> <name> <email> <age>\n"
    "\n"
    "\t** Notice: The <name> & <email> are string without any whitespace character, and maximum length of them is 255. **\n"
    "\n"
    "  * select\n"
    "\tThis cmd will display all user records in the table.\n"
    "\n";
    printf("%s", msg);
}

