#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Where.h"
#include "Table.h"
#include "Command.h"
#include "Update.h"
#include "User.h"

Update_query_t *new_update_query(){
  Update_query_t *uq = (Update_query_t*)malloc(sizeof(Update_query_t));
  memset((void*)uq, 0, sizeof(Update_query_t));
  uq->set_num = 0;
  return uq;
}
// 把 set 後面的句子作分解，left 中存 column name，right 存值
void handle_update_set(Command_t *cmd, Update_query_t *uq, int i){
  i++;
  while(i < cmd->args_len && strncmp(cmd->args[i], "where", 10)){
    // 把左右兩邊字串給 left, right
    // 四種可能 1.a=b  2.a =b  3.a= b  4.a = b
    // 把沒有 = 的也算在 a=b 形式中
    // 4
    if(i+1<cmd->args_len && !strncmp(cmd->args[i+1], "=", 10)){
      for(int j=0; j<strlen(cmd->args[i]); j++)uq->left[uq->set_num][j] = cmd->args[i][j];
      for(int j=0; j<strlen(cmd->args[i+2]); j++)
        if(j!=strlen(cmd->args[i+2])-1 || cmd->args[i+2][strlen(cmd->args[i+2])-1]!=',')uq->right[uq->set_num][j] = cmd->args[i+2][j];
      i+=3;
    }
    // 2
    else if(!strstr(cmd->args[i], "=") && i+1 < cmd->args_len && cmd->args[i+1][0]=='='){
      for(int j=0; j<strlen(cmd->args[i]); j++)uq->left[uq->set_num][j] = cmd->args[i][j];
      for(int j=1; j<strlen(cmd->args[i+1]); j++)
        if(j!=strlen(cmd->args[i+1])-1 || cmd->args[i+1][strlen(cmd->args[i+1])-1]!=',')uq->right[uq->set_num][j-1] = cmd->args[i+1][j];
      i+=2;
    }
    // 1
    else if(strstr(cmd->args[i], "=") && cmd->args[i][strlen(cmd->args[i])-1] != '='){
      // 確認 = 的位子，
      int equal_pos=1;
      for(int j=0; j < strlen(cmd->args[i]); j++){
        if(cmd->args[i][j] == '=')equal_pos = j;
      }
      for(int j=0; j<equal_pos; j++){
        uq->left[uq->set_num][j] = cmd->args[i][j];
      }
      for(int j=equal_pos+1; j < strlen(cmd->args[i]); j++){
        if(j!=strlen(cmd->args[i])-1 || cmd->args[i][strlen(cmd->args[i])-1]!=',')uq->right[uq->set_num][j-(equal_pos+1)] = cmd->args[i][j];
      }
      i++;
    }
    // 3
    else if(cmd->args[i][strlen(cmd->args[i])-1] == '=' ){
      for(int j=0; j<strlen(cmd->args[i])-1; j++)uq->left[uq->set_num][j] = cmd->args[i][j];
      for(int j=0; j<strlen(cmd->args[i+1]); j++)
        if(j!=strlen(cmd->args[i+1])-1 || cmd->args[i+1][strlen(cmd->args[i+1])-1]!=',')uq->right[uq->set_num][j] = cmd->args[i+1][j];
      i+=2;
    }
    uq->set_num++;
  }
}
// 檢查有沒有錯誤，有就回傳 0，沒有回傳 1
int check_update_error(Table_t *table, Update_query_t *uq, Where_arg_t *arg){
  char white_list[4][20]={"id", "name", "email", "age"};
  // 檢查 left 是否都是 column name，檢查更改的值為 id, age 時，right 是否為數字
  for(int i=0; i<uq->set_num; i++){
    int check = 0;
    for(int j=0; j<4; j++){
      if(!strncmp(uq->left[i], white_list[j], 10)){
        check = 1;
        if((j==0 || j==3) && !check_whether_num(uq->right[i])){
          handle_update_error(1);
          return 0;
        }
      }
    }
    if(!check){
      handle_update_error(0);
      return 0;
    }
  }
  // 檢查如果要改 primary key(id) 時，符合的超過一項
  int change_primary_key=0;
  for(int i=0; i<uq->set_num; i++){
    if(!strncmp(uq->left[i], white_list[0], 10)){
      change_primary_key=1;
      break;
    }
  }
  if(change_primary_key){
    int duplicate=0;
    for(int i=0; i<table->len; i++){
      User_t *user=get_User(table, i);
      if(user != NULL){
        if(meet_where_condition(user, arg)){
          if(duplicate){
            handle_update_error(2);
            return 0;
          }
          else duplicate=1;
        }
      }
    }
  }
  return 1;
}
// 開始更新 table
void update_table(Table_t *table, Update_query_t *uq, Where_arg_t *arg){
  char white_list[4][20]={"id", "name", "email", "age"};
  for(int i=0; i<table->len; i++){
    User_t *user=get_User(table, i);
    if(meet_where_condition(user, arg)){
      for(int j=0; j<uq->set_num; j++){
        if(!strncmp(uq->left[j], white_list[0], 10))user->id = atoi(uq->right[j]);
        else if(!strncmp(uq->left[j], white_list[1], 10))strcpy(user->name, uq->right[j]);
        else if(!strncmp(uq->left[j], white_list[2], 10))strcpy(user->email, uq->right[j]);
        else user->age = atoi(uq->right[j]);
      }
    }
  }
}

void handle_update_error(int errcode){
  switch(errcode){
    case 0:{
      printf("undefined column name in update\n");
      break;
    }
    case 1:{
      printf("wrong datatype in update\n");
      break;
    }
    case 2:{
      printf("duplicate primary key\n");
      break;
    }
    case 3:{
      printf("something wrong in update\n");
      break;
    }
  }
}